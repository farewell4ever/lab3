﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp8
{
    [Serializable]
    class Choice
    {
        public string Description { get; set; }
        public int NextRoom { get; set; }

        public Choice(string description, int nextRoom)
        {
            Description = description;
            NextRoom = nextRoom;
        }
    }
}
